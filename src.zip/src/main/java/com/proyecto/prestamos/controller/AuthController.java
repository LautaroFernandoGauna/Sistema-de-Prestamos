package com.proyecto.prestamos.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.proyecto.prestamos.model.User;
import com.proyecto.prestamos.repository.UserRepository;
import com.proyecto.prestamos.security.JwtUtil;
import com.proyecto.prestamos.service.TokenRevocationService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PasswordEncoder encoder;
    private final JwtUtil jwtUtils;
    private final TokenRevocationService tokenRevocationService;

    public AuthController(AuthenticationManager authenticationManager,
                          UserRepository userRepository,
                          PasswordEncoder encoder,
                          JwtUtil jwtUtils,
                          TokenRevocationService tokenRevocationService) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.encoder = encoder;
        this.jwtUtils = jwtUtils;
        this.tokenRevocationService = tokenRevocationService;
    }

    @PostMapping("/signin")
    public String authenticateUser(@RequestBody User user) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return jwtUtils.generateToken(userDetails.getUsername());
    }

    @PostMapping("/signup")
    public String registerUser(@RequestBody User user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            return "Error: El nombre de usuario ya está ocupado!";
        }
        User newUser = new User(null, user.getUsername(), encoder.encode(user.getPassword()));
        userRepository.save(newUser);
        return "Usuario registrado correctamente!";
    }

    /**
     * Enviar Authorization: Bearer <JWT> sin cuerpo en el POST.
     * El filtro comprueba que el JWT sea válido y no haya sido revocado.
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestHeader("Authorization") String authorization) {
        String jwt = authorization.substring(7); // El filtro ya validó el prefijo Bearer.
        tokenRevocationService.revoke(jwt);
        return ResponseEntity.ok("Sesión cerrada: JWT revocado correctamente.");
    }
}
